import React from "react";

const SearchPage = () => {
  return (
    <div>
      <h1>🔎 Recherche patient</h1>
      <p>Recherche et accès aux dossiers patients.</p>
    </div>
  );
};

export default SearchPage;
