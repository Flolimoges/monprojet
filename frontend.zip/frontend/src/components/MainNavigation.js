import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Calendar, Home, FileText } from "react-feather";
import "./MainNavigation.css";

const MainNavigation = () => {
  const location = useLocation();

  return (
    <nav>
      <NavLink to="/home" className={`nav-item ${location.pathname === "/home" ? "active" : ""}`}>
        <span className="nav-icon"><Home size={24} /></span>
        <span className="nav-label">Accueil</span>
      </NavLink>

      <NavLink to="/appointments" className={`nav-item ${location.pathname === "/appointments" ? "active" : ""}`}>
        <span className="nav-icon"><Calendar size={24} /></span>
        <span className="nav-label">Rendez-vous</span>
      </NavLink>

      <NavLink to="/records" className={`nav-item ${location.pathname === "/records" ? "active" : ""}`}>
        <span className="nav-icon"><FileText size={24} /></span>
        <span className="nav-label">Dossiers</span>
      </NavLink>
    </nav>
  );
};

export default MainNavigation;