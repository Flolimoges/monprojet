import React from "react";

const CalendarPage = () => {
  return (
    <div>
      <h1>📅 Calendrier des consultations</h1>
      <p>Affichage du planning des rendez-vous.</p>
    </div>
  );
};

export default CalendarPage;
