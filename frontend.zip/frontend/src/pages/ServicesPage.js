import React from "react";

const ServicesPage = () => {
  return (
    <div>
      <h1>🏥 Services hospitaliers</h1>
      <p>Affichage des patients hospitalisés.</p>
    </div>
  );
};

export default ServicesPage;
